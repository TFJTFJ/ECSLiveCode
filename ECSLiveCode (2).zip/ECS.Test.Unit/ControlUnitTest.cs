﻿using NSubstitute;
using NUnit.Framework;

namespace ECS.Test.Unit
{
    [TestFixture]
    class ControlUnitTest
    {
        private IHeater _heater;
        private ITempSensor _tempSensor;
        private Control _uut;

        [SetUp]
        public void Setup()
        {
            _heater = Substitute.For<IHeater>();
            _tempSensor = Substitute.For<ITempSensor>();
            _uut = new Control(_heater, _tempSensor, 25);
        }

        [Test]
        public void Regulate_HighTemp_HeaterIsTurnedOff()
        {
            _tempSensor.GetTemp().Returns(27);
            _uut.Regulate();

            _heater.Received().TurnOff();
        }

        [Test]
        public void Regulate_LowTemp_HeaterIsTurnedOn()
        {
            _tempSensor.GetTemp().Returns(23);
            _uut.Regulate();

            _heater.Received().TurnOn();
        }


    }
}
